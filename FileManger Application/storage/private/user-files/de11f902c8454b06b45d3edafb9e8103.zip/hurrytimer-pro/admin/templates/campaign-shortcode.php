<p><?php esc_html_e('Copy this shortcode and paste it into your post, page, or text widget content:', "hurrytimer"); ?></p>
<input style="min-width:100%" type="text" readonly onfocus="this.select()" value="[hurrytimer id=&quot;<?php echo esc_attr($post_id); ?>&quot;]"]>

